# AudioViz
Audio visualizer with slider
